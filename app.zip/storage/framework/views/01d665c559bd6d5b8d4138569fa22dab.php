<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('User Details')); ?>

            </h2>
            <div>
                <a href="<?php echo e(route('users.edit', $user)); ?>" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mr-2">
                    Edit User
                </a>
                <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded" onclick="return confirm('Are you sure you want to delete this user?')">
                        Delete User
                    </button>
                </form>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex items-start space-x-6 mb-6">
                        <!-- Profile Picture -->
                        <div class="flex-shrink-0">
                            <?php if($user->profile_picture): ?>
                                <img src="<?php echo e(asset('storage/' . $user->profile_picture)); ?>" 
                                    alt="<?php echo e($user->name); ?>'s Profile Picture" 
                                    class="h-32 w-32 rounded-full object-cover border-4 border-yellow-200">
                            <?php else: ?>
                                <div class="h-32 w-32 rounded-full bg-yellow-100 flex items-center justify-center border-4 border-yellow-200">
                                    <span class="text-yellow-800 font-bold text-3xl">
                                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- User Information Header -->
                        <div class="flex-grow">
                            <h3 class="text-lg font-semibold text-gray-900 mb-1">User Information</h3>
                            <p class="text-sm text-gray-500">Account details and roles</p>
                        </div>
                    </div>

                    <dl class="grid grid-cols-1 gap-4">
                        <div>
                            <dt class="text-sm font-medium text-yellow-600">Name</dt>
                            <dd class="mt-1 text-sm text-gray-900"><?php echo e($user->name); ?></dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-yellow-600">Email</dt>
                            <dd class="mt-1 text-sm text-gray-900"><?php echo e($user->email); ?></dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-yellow-600">Roles</dt>
                            <dd class="mt-1">
                                <div class="flex flex-wrap gap-1">
                                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                            <?php echo e(ucfirst($role->name)); ?>

                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-yellow-600">Created At</dt>
                            <dd class="mt-1 text-sm text-gray-900"><?php echo e($user->created_at->format('Y-m-d H:i:s')); ?></dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-yellow-600">Last Updated</dt>
                            <dd class="mt-1 text-sm text-gray-900"><?php echo e($user->updated_at->format('Y-m-d H:i:s')); ?></dd>
                        </div>
                    </dl>
                </div>
            </div>

            <?php if($user->member || $user->staff || $user->player): ?>
            <div class="mt-6 bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Associated Records</h3>
                    <dl class="grid grid-cols-1 gap-4">
                        <?php if($user->member): ?>
                        <div>
                            <dt class="text-sm font-medium text-yellow-600">Member</dt>
                            <dd class="mt-1">
                                <a href="<?php echo e(route('members.show', $user->member)); ?>" class="text-yellow-600 hover:text-yellow-900">
                                    <?php echo e($user->member->membership_number); ?> - <?php echo e($user->member->first_name); ?> <?php echo e($user->member->last_name); ?>

                                </a>
                            </dd>
                        </div>
                        <?php endif; ?>

                        <?php if($user->staff): ?>
                        <div>
                            <dt class="text-sm font-medium text-yellow-600">Staff</dt>
                            <dd class="mt-1">
                                <a href="<?php echo e(route('staff.show', $user->staff)); ?>" class="text-yellow-600 hover:text-yellow-900">
                                    <?php echo e($user->staff->employee_id); ?> - <?php echo e($user->staff->first_name); ?> <?php echo e($user->staff->last_name); ?>

                                </a>
                            </dd>
                        </div>
                        <?php endif; ?>

                        <?php if($user->player): ?>
                        <div>
                            <dt class="text-sm font-medium text-yellow-600">Player</dt>
                            <dd class="mt-1">
                                <a href="<?php echo e(route('players.show', $user->player)); ?>" class="text-yellow-600 hover:text-yellow-900">
                                    <?php echo e($user->player->first_name); ?> <?php echo e($user->player->last_name); ?> - <?php echo e($user->player->position); ?>

                                </a>
                            </dd>
                        </div>
                        <?php endif; ?>
                    </dl>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> <?php /**PATH C:\Users\Dhanushka\Desktop\yssc-system\resources\views/users/show.blade.php ENDPATH**/ ?>