<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Attendance Management')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <!-- Stats Overview -->
            <div class="grid grid-cols-1 gap-4 mb-8 sm:grid-cols-2 lg:grid-cols-6">
                <!-- Match Stats -->
                <div class="p-4 bg-purple-50 rounded-lg shadow sm:p-6">
                    <dt class="text-sm font-medium text-purple-700 truncate">Total Matches</dt>
                    <dd class="mt-1 text-3xl font-semibold text-purple-900"><?php echo e($stats['match']['total']); ?></dd>
                    <p class="mt-2 text-sm text-purple-600">
                        Present Rate: <?php echo e($stats['match']['total'] > 0 ? number_format(($stats['match']['present_rate'] / ($stats['match']['present_rate'] + $stats['match']['absent_rate'])) * 100, 1) : 0); ?>%
                    </p>
                </div>

                <!-- Practice Stats -->
                <div class="p-4 bg-blue-50 rounded-lg shadow sm:p-6">
                    <dt class="text-sm font-medium text-blue-700 truncate">Total Practices</dt>
                    <dd class="mt-1 text-3xl font-semibold text-blue-900"><?php echo e($stats['practice']['total']); ?></dd>
                    <p class="mt-2 text-sm text-blue-600">
                        Present Rate: <?php echo e($stats['practice']['total'] > 0 ? number_format(($stats['practice']['present_rate'] / ($stats['practice']['present_rate'] + $stats['practice']['absent_rate'])) * 100, 1) : 0); ?>%
                    </p>
                </div>

                <!-- Meeting Stats -->
                <div class="p-4 bg-gray-50 rounded-lg shadow sm:p-6">
                    <dt class="text-sm font-medium text-gray-700 truncate">Total Meetings</dt>
                    <dd class="mt-1 text-3xl font-semibold text-gray-900"><?php echo e($stats['meeting']['total']); ?></dd>
                    <p class="mt-2 text-sm text-gray-600">
                        Present Rate: <?php echo e($stats['meeting']['total'] > 0 ? number_format(($stats['meeting']['present_rate'] / ($stats['meeting']['present_rate'] + $stats['meeting']['absent_rate'])) * 100, 1) : 0); ?>%
                    </p>
                </div>

                <!-- People Stats -->
                <div class="p-4 bg-white rounded-lg shadow sm:p-6">
                    <dt class="text-sm font-medium text-gray-500 truncate">Active Players</dt>
                    <dd class="mt-1 text-3xl font-semibold text-gray-900"><?php echo e($stats['total_players']); ?></dd>
                </div>
                <div class="p-4 bg-white rounded-lg shadow sm:p-6">
                    <dt class="text-sm font-medium text-gray-500 truncate">Active Staff</dt>
                    <dd class="mt-1 text-3xl font-semibold text-gray-900"><?php echo e($stats['total_staff']); ?></dd>
                </div>
                <div class="p-4 bg-white rounded-lg shadow sm:p-6">
                    <dt class="text-sm font-medium text-gray-500 truncate">Active Members</dt>
                    <dd class="mt-1 text-3xl font-semibold text-gray-900"><?php echo e($stats['total_members']); ?></dd>
                </div>
            </div>

            <!-- Events List -->
            <?php $__currentLoopData = ['match' => 'Matches', 'practice' => 'Practice Sessions', 'meeting' => 'Meetings']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mb-8">
                    <div class="p-6 text-gray-900">
                        <div class="sm:flex sm:items-center sm:justify-between">
                            <div>
                                <h3 class="text-lg font-medium leading-6 text-gray-900"><?php echo e($title); ?></h3>
                                <p class="mt-1 text-sm text-gray-500">Manage attendance for <?php echo e(strtolower($title)); ?></p>
                            </div>
                        </div>

                        <div class="mt-8 flow-root">
                            <div class="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                                <div class="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                                    <table class="min-w-full divide-y divide-gray-300">
                                        <thead>
                                            <tr>
                                                <th scope="col" class="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-0">Event</th>
                                                <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Date & Time</th>
                                                <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Status</th>
                                                <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Players</th>
                                                <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Staff</th>
                                                <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Members</th>
                                                <th scope="col" class="relative py-3.5 pl-3 pr-4 sm:pr-0">
                                                    <span class="sr-only">Actions</span>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody class="divide-y divide-gray-200">
                                            <?php $__empty_1 = true; $__currentLoopData = $eventsByType[$type]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td class="py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-0">
                                                        <?php echo e($event->title); ?>

                                                    </td>
                                                    <td class="px-3 py-4 text-sm text-gray-500">
                                                        <?php echo e($event->start_time->format('M d, Y h:i A')); ?>

                                                    </td>
                                                    <td class="px-3 py-4 text-sm text-gray-500">
                                                        <span class="inline-flex items-center px-2 py-1 text-xs font-medium rounded-md
                                                            <?php if($event->status === 'scheduled'): ?> bg-yellow-100 text-yellow-700
                                                            <?php elseif($event->status === 'in_progress'): ?> bg-blue-100 text-blue-700
                                                            <?php elseif($event->status === 'completed'): ?> bg-green-100 text-green-700
                                                            <?php else: ?> bg-red-100 text-red-700
                                                            <?php endif; ?>">
                                                            <?php echo e(str_replace('_', ' ', ucfirst($event->status))); ?>

                                                        </span>
                                                    </td>
                                                    <td class="px-3 py-4 text-sm text-gray-500">
                                                        <?php
                                                            $playerStats = $event->getAttendanceStatsByType('players');
                                                        ?>
                                                        <?php if($playerStats['total'] > 0): ?>
                                                            <div class="flex items-center gap-2">
                                                                <div class="w-16 h-2 bg-gray-200 rounded-full">
                                                                    <div class="h-2 bg-green-500 rounded-full" style="width: <?php echo e(($playerStats['present'] / $playerStats['total']) * 100); ?>%"></div>
                                                                </div>
                                                                <span><?php echo e($playerStats['present']); ?>/<?php echo e($playerStats['total']); ?></span>
                                                            </div>
                                                        <?php else: ?>
                                                            <span class="text-gray-400">No records</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="px-3 py-4 text-sm text-gray-500">
                                                        <?php
                                                            $staffStats = $event->getAttendanceStatsByType('staff');
                                                        ?>
                                                        <?php if($staffStats['total'] > 0): ?>
                                                            <div class="flex items-center gap-2">
                                                                <div class="w-16 h-2 bg-gray-200 rounded-full">
                                                                    <div class="h-2 bg-green-500 rounded-full" style="width: <?php echo e(($staffStats['present'] / $staffStats['total']) * 100); ?>%"></div>
                                                                </div>
                                                                <span><?php echo e($staffStats['present']); ?>/<?php echo e($staffStats['total']); ?></span>
                                                            </div>
                                                        <?php else: ?>
                                                            <span class="text-gray-400">No records</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="px-3 py-4 text-sm text-gray-500">
                                                        <?php
                                                            $memberStats = $event->getAttendanceStatsByType('members');
                                                        ?>
                                                        <?php if($memberStats['total'] > 0): ?>
                                                            <div class="flex items-center gap-2">
                                                                <div class="w-16 h-2 bg-gray-200 rounded-full">
                                                                    <div class="h-2 bg-green-500 rounded-full" style="width: <?php echo e(($memberStats['present'] / $memberStats['total']) * 100); ?>%"></div>
                                                                </div>
                                                                <span><?php echo e($memberStats['present']); ?>/<?php echo e($memberStats['total']); ?></span>
                                                            </div>
                                                        <?php else: ?>
                                                            <span class="text-gray-400">No records</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="relative py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-0">
                                                        <?php if($event->status === 'scheduled' || $event->status === 'in_progress'): ?>
                                                            <div class="flex items-center justify-end gap-2">
                                                                <a href="<?php echo e(route('events.attendances.create', $event)); ?>?type=players" class="text-indigo-600 hover:text-indigo-900">Players</a>
                                                                <span class="text-gray-300">|</span>
                                                                <a href="<?php echo e(route('events.attendances.create', $event)); ?>?type=staff" class="text-indigo-600 hover:text-indigo-900">Staff</a>
                                                                <span class="text-gray-300">|</span>
                                                                <a href="<?php echo e(route('events.attendances.create', $event)); ?>?type=members" class="text-indigo-600 hover:text-indigo-900">Members</a>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="flex items-center justify-end gap-2">
                                                                <a href="<?php echo e(route('events.attendances.report', $event)); ?>?type=players" class="text-gray-600 hover:text-gray-900">Players</a>
                                                                <span class="text-gray-300">|</span>
                                                                <a href="<?php echo e(route('events.attendances.report', $event)); ?>?type=staff" class="text-gray-600 hover:text-gray-900">Staff</a>
                                                                <span class="text-gray-300">|</span>
                                                                <a href="<?php echo e(route('events.attendances.report', $event)); ?>?type=members" class="text-gray-600 hover:text-gray-900">Members</a>
                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="7" class="px-3 py-4 text-sm text-center text-gray-500">
                                                        No <?php echo e(strtolower($title)); ?> found
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> <?php /**PATH C:\Users\Dhanushka\Desktop\yssc-system\resources\views/attendances/index.blade.php ENDPATH**/ ?>