<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">
                    <?php echo e(__('Take Attendance')); ?>

                </h2>
                <p class="mt-1 text-sm text-gray-600">
                    <?php echo e($event->title); ?> - <?php echo e($event->start_time->format('M d, Y h:i A')); ?> to <?php echo e($event->end_time->format('h:i A')); ?>

                </p>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <form method="POST" action="<?php echo e(route('events.attendances.store', $event)); ?>" class="p-6">
                    <?php echo csrf_field(); ?>

                    <?php if (isset($component)) { $__componentOriginala4bf677c1565e5b881cc0b27c50d6cbb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala4bf677c1565e5b881cc0b27c50d6cbb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.attendances.form','data' => ['event' => $event,'attendees' => $attendees,'existingAttendances' => $existingAttendances,'type' => $type]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('attendances.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['event' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event),'attendees' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attendees),'existingAttendances' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($existingAttendances),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($type)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala4bf677c1565e5b881cc0b27c50d6cbb)): ?>
<?php $attributes = $__attributesOriginala4bf677c1565e5b881cc0b27c50d6cbb; ?>
<?php unset($__attributesOriginala4bf677c1565e5b881cc0b27c50d6cbb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala4bf677c1565e5b881cc0b27c50d6cbb)): ?>
<?php $component = $__componentOriginala4bf677c1565e5b881cc0b27c50d6cbb; ?>
<?php unset($__componentOriginala4bf677c1565e5b881cc0b27c50d6cbb); ?>
<?php endif; ?>

                    <div class="flex items-center justify-end mt-6 gap-x-6">
                        <a href="<?php echo e(route('events.show', $event)); ?>" class="text-sm font-semibold leading-6 text-gray-900">Cancel</a>
                        <button type="submit" class="px-3 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-md shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
                            Save Attendance
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> <?php /**PATH C:\Users\Dhanushka\Desktop\yssc-system\resources\views/attendances/create.blade.php ENDPATH**/ ?>