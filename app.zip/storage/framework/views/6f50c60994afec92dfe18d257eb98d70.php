<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Invoice #<?php echo e($transaction->transaction_number); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        .invoice-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .club-logo {
            max-width: 150px;
            margin-bottom: 10px;
        }
        .invoice-title {
            font-size: 24px;
            color: #333;
            margin-bottom: 5px;
        }
        .club-details {
            margin-bottom: 20px;
            font-size: 14px;
            color: #666;
        }
        .invoice-info {
            margin-bottom: 30px;
        }
        .invoice-info table {
            width: 100%;
        }
        .invoice-info td {
            padding: 5px;
            vertical-align: top;
        }
        .transaction-details {
            margin-bottom: 30px;
        }
        .transaction-details table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .transaction-details th, .transaction-details td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        .transaction-details th {
            background-color: #f8f8f8;
        }
        .amount {
            text-align: right;
        }
        .total {
            font-weight: bold;
        }
        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }
        .signature {
            margin-top: 50px;
            border-top: 1px solid #ddd;
            padding-top: 10px;
            text-align: right;
        }
        @media print {
            .no-print {
                display: none;
            }
            .signature img {
                max-width: 200px;
                height: auto;
            }
        }
    </style>
</head>
<body>
    <div class="invoice-box">
        <!-- Header -->
        <div class="header">
            <div class="logo">
                <?php if($clubSettings && $clubSettings->logo_path): ?>
                    <img src="<?php echo e(storage_path('app/public/' . $clubSettings->logo_path)); ?>" alt="Club Logo" style="max-width: 200px;">
                <?php endif; ?>
            </div>
            <div class="club-info">
                <h1><?php echo e($clubSettings->name ?? config('club.name')); ?></h1>
                <p><?php echo e($clubSettings->address ?? config('club.address')); ?></p>
                <p>Phone: <?php echo e($clubSettings->phone ?? config('club.phone')); ?></p>
                <p>Email: <?php echo e($clubSettings->email ?? config('club.email')); ?></p>
                <?php if($clubSettings->registration_number): ?>
                    <p>Registration No: <?php echo e($clubSettings->registration_number); ?></p>
                <?php endif; ?>
                <?php if($clubSettings->tax_number): ?>
                    <p>Tax No: <?php echo e($clubSettings->tax_number); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <div class="invoice-info">
            <table>
                <tr>
                    <td width="50%">
                        <strong>Bill To:</strong><br>
                        <?php if($transaction->transactionable): ?>
                            <?php echo e(class_basename($transaction->transactionable_type)); ?>: <?php echo e($transaction->transactionable->name); ?><br>
                            <?php if($transaction->transactionable->email): ?>
                                Email: <?php echo e($transaction->transactionable->email); ?><br>
                            <?php endif; ?>
                            <?php if($transaction->transactionable->phone): ?>
                                Phone: <?php echo e($transaction->transactionable->phone); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            Other
                        <?php endif; ?>
                    </td>
                    <td width="50%" style="text-align: right;">
                        <strong>Invoice Number:</strong> <?php echo e($transaction->transaction_number); ?><br>
                        <strong>Date:</strong> <?php echo e($transaction->transaction_date->format('Y-m-d')); ?><br>
                        <strong>Payment Method:</strong> <?php echo e(ucfirst($transaction->payment_method)); ?>

                    </td>
                </tr>
            </table>
        </div>

        <div class="transaction-details">
            <table>
                <thead>
                    <tr>
                        <th>Description</th>
                        <th>Category</th>
                        <th>Reference</th>
                        <th class="amount">Amount (LKR)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($transaction->description); ?></td>
                        <td><?php echo e(ucfirst($transaction->category)); ?></td>
                        <td><?php echo e($transaction->reference_number ?: '-'); ?></td>
                        <td class="amount"><?php echo e(number_format($transaction->amount, 2)); ?></td>
                    </tr>
                    <tr>
                        <td colspan="3" class="total" style="text-align: right;">Total:</td>
                        <td class="amount total"><?php echo e(number_format($transaction->amount, 2)); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="signature">
            <?php if($transaction->signature): ?>
                <img src="<?php echo e($transaction->signature); ?>" alt="Signature" style="max-width: 200px; margin-bottom: 10px;">
            <?php endif; ?>
            <p>Authorized Signature</p>
            <p>Name: <?php echo e($transaction->signatory_name ?: auth()->user()->name); ?></p>
            <p>Designation: <?php echo e($transaction->signatory_designation ?: 'Authorized Officer'); ?></p>
            <p>Date: <?php echo e(now()->format('Y-m-d')); ?></p>
        </div>

        <div class="no-print">
            <form method="POST" action="<?php echo e(route('financial-transactions.update-signature', $transaction)); ?>" class="mt-4">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <?php if (isset($component)) { $__componentOriginal72332feea9f878ab2343bb6e35d6719d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72332feea9f878ab2343bb6e35d6719d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.signature-pad','data' => ['name' => 'signature','label' => 'Add Signature']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('signature-pad'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'signature','label' => 'Add Signature']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72332feea9f878ab2343bb6e35d6719d)): ?>
<?php $attributes = $__attributesOriginal72332feea9f878ab2343bb6e35d6719d; ?>
<?php unset($__attributesOriginal72332feea9f878ab2343bb6e35d6719d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72332feea9f878ab2343bb6e35d6719d)): ?>
<?php $component = $__componentOriginal72332feea9f878ab2343bb6e35d6719d; ?>
<?php unset($__componentOriginal72332feea9f878ab2343bb6e35d6719d); ?>
<?php endif; ?>
                <div class="mt-4">
                    <button type="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded">
                        Save Signature
                    </button>
                </div>
            </form>
        </div>

        <div class="footer">
            <p>Thank you for your business!</p>
            <p><?php echo e($clubSettings->name); ?> - Nurturing Young Sports Talent</p>
        </div>
    </div>
</body>
</html> <?php /**PATH C:\Users\Dhanushka\Desktop\yssc-system\resources\views\financial-transactions\invoice.blade.php ENDPATH**/ ?>