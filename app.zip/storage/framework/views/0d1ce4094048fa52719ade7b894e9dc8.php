<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Bank Account Details')); ?>

            </h2>
            <div>
                <a href="<?php echo e(route('bank-accounts.edit', $bankAccount)); ?>" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded mr-2">
                    Edit Account
                </a>
                <form action="<?php echo e(route('bank-accounts.destroy', $bankAccount)); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded" onclick="return confirm('Are you sure you want to delete this account?')">
                        Delete Account
                    </button>
                </form>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Account Information -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Account Information</h3>
                        <dl class="grid grid-cols-1 gap-4">
                            <div>
                                <dt class="text-sm font-medium text-yellow-600">Account Name</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($bankAccount->account_name); ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-yellow-600">Account Number</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($bankAccount->account_number); ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-yellow-600">Bank Name</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($bankAccount->bank_name); ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-yellow-600">Branch Name</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($bankAccount->branch_name); ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-yellow-600">Swift Code</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e($bankAccount->swift_code ?? 'N/A'); ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-yellow-600">Account Type</dt>
                                <dd class="mt-1 text-sm text-gray-900"><?php echo e(ucfirst(str_replace('_', ' ', $bankAccount->account_type))); ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-yellow-600">Current Balance</dt>
                                <dd class="mt-1 text-sm text-gray-900">LKR <?php echo e(number_format($bankAccount->current_balance, 2)); ?></dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-yellow-600">Status</dt>
                                <dd class="mt-1">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?php if($bankAccount->status === 'active'): ?> bg-green-100 text-green-800
                                        <?php elseif($bankAccount->status === 'inactive'): ?> bg-yellow-100 text-yellow-800
                                        <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                                        <?php echo e(ucfirst($bankAccount->status)); ?>

                                    </span>
                                </dd>
                            </div>
                        </dl>
                    </div>
                </div>

                <!-- Recent Transactions -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-lg font-semibold text-gray-900">Recent Transactions</h3>
                            <a href="<?php echo e(route('financial-transactions.create', ['bank_account_id' => $bankAccount->id])); ?>" class="text-yellow-600 hover:text-yellow-900">Add Transaction →</a>
                        </div>
                        <?php if($bankAccount->financialTransactions->count() > 0): ?>
                            <div class="space-y-4">
                                <?php $__currentLoopData = $bankAccount->financialTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                                        <div>
                                            <p class="text-sm font-medium text-gray-900"><?php echo e($transaction->description); ?></p>
                                            <p class="text-xs text-gray-500"><?php echo e($transaction->transaction_date->format('Y-m-d')); ?></p>
                                        </div>
                                        <div class="text-right">
                                            <p class="text-sm font-medium <?php if($transaction->type === 'income'): ?> text-green-600 <?php else: ?> text-red-600 <?php endif; ?>">
                                                <?php echo e($transaction->type === 'income' ? '+' : '-'); ?> LKR <?php echo e(number_format($transaction->amount, 2)); ?>

                                            </p>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                <?php if($transaction->status === 'completed'): ?> bg-green-100 text-green-800
                                                <?php elseif($transaction->status === 'pending'): ?> bg-yellow-100 text-yellow-800
                                                <?php else: ?> bg-red-100 text-red-800 <?php endif; ?>">
                                                <?php echo e(ucfirst($transaction->status)); ?>

                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <p class="text-sm text-gray-500">No transactions found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <!-- Interbank Transfers -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-lg font-semibold text-gray-900">Interbank Transfers</h3>
                            <a href="<?php echo e(route('interbank-transfers.create', ['from_account_id' => $bankAccount->id])); ?>" class="text-yellow-600 hover:text-yellow-900">New Transfer →</a>
                        </div>
                        <?php
                            $incomingTransfers = $bankAccount->incomingTransfers()->latest('transfer_date')->take(5)->get();
                            $outgoingTransfers = $bankAccount->outgoingTransfers()->latest('transfer_date')->take(5)->get();
                            $transfers = $incomingTransfers->concat($outgoingTransfers)->sortByDesc('transfer_date')->take(5);
                        ?>
                        <?php if($transfers->count() > 0): ?>
                            <div class="space-y-4">
                                <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                                        <div>
                                            <p class="text-sm font-medium text-gray-900">
                                                <?php if($transfer->from_account_id === $bankAccount->id): ?>
                                                    To: <?php echo e($transfer->toAccount->bank_name); ?> - <?php echo e($transfer->toAccount->account_number); ?>

                                                <?php else: ?>
                                                    From: <?php echo e($transfer->fromAccount->bank_name); ?> - <?php echo e($transfer->fromAccount->account_number); ?>

                                                <?php endif; ?>
                                            </p>
                                            <p class="text-xs text-gray-500"><?php echo e($transfer->transfer_date->format('Y-m-d')); ?></p>
                                        </div>
                                        <div class="text-right">
                                            <p class="text-sm font-medium <?php if($transfer->from_account_id === $bankAccount->id): ?> text-red-600 <?php else: ?> text-green-600 <?php endif; ?>">
                                                <?php echo e($transfer->from_account_id === $bankAccount->id ? '-' : '+'); ?> <?php echo e($bankAccount->currency); ?> <?php echo e(number_format($transfer->amount, 2)); ?>

                                            </p>
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                <?php if($transfer->status === 'completed'): ?> bg-green-100 text-green-800
                                                <?php elseif($transfer->status === 'pending'): ?> bg-yellow-100 text-yellow-800
                                                <?php elseif($transfer->status === 'failed'): ?> bg-red-100 text-red-800
                                                <?php else: ?> bg-gray-100 text-gray-800 <?php endif; ?>">
                                                <?php echo e(ucfirst($transfer->status)); ?>

                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="mt-4 text-right">
                                <a href="<?php echo e(route('interbank-transfers.index', ['account_id' => $bankAccount->id])); ?>" class="text-sm text-yellow-600 hover:text-yellow-900">View All Transfers →</a>
                            </div>
                        <?php else: ?>
                            <p class="text-sm text-gray-500">No interbank transfers found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> <?php /**PATH C:\Users\Dhanushka\Desktop\yssc-system\resources\views\bank-accounts\show.blade.php ENDPATH**/ ?>