<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Receipt - <?php echo e($transaction->transaction_number); ?></title>
    <style>
        @page {
            margin: 0;
        }
        body {
            font-family: 'Helvetica', Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: #fff;
            color: #333;
            font-size: 12px;
        }
        .container {
            max-width: 100%;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        .logo {
            margin-bottom: 15px;
        }
        .logo img {
            max-width: 120px;
            max-height: 60px;
            object-fit: contain;
        }
        .club-info {
            margin-bottom: 20px;
        }
        .club-info h1 {
            font-size: 20px;
            color: #2c3e50;
            margin: 0 0 10px 0;
            font-weight: 600;
        }
        .club-info p {
            margin: 4px 0;
            color: #555;
            font-size: 12px;
            line-height: 1.4;
        }
        .receipt-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 8px;
            color: #2c3e50;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .receipt-number {
            font-size: 13px;
            color: #666;
            font-weight: 500;
            background: #f8f9fa;
            padding: 4px 10px;
            border-radius: 4px;
            display: inline-block;
        }
        .info-section {
            margin-bottom: 15px;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 6px;
        }
        .info-row {
            margin-bottom: 8px;
            display: flex;
            align-items: center;
        }
        .info-row:last-child {
            margin-bottom: 0;
        }
        .label {
            font-weight: 600;
            width: 140px;
            color: #2c3e50;
            font-size: 12px;
        }
        .value {
            flex: 1;
            color: #444;
            font-size: 12px;
        }
        .amount {
            font-size: 14px;
            font-weight: 600;
            color: #2c3e50;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 11px;
            color: #666;
            padding-top: 15px;
            border-top: 2px solid #f0f0f0;
        }
        .status {
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: 500;
            font-size: 11px;
            display: inline-block;
        }
        .status-completed {
            color: #0f5132;
            background: #d1e7dd;
        }
        .status-pending {
            color: #664d03;
            background: #fff3cd;
        }
        .status-cancelled {
            color: #842029;
            background: #f8d7da;
        }
        .signature-section {
            margin-top: 20px;
            text-align: right;
            padding: 15px;
            border-top: 1px solid #f0f0f0;
        }
        .signature-image {
            max-width: 120px;
            max-height: 60px;
            margin-bottom: 5px;
            object-fit: contain;
        }
        .signature-info {
            font-size: 11px;
            color: #666;
            line-height: 1.3;
        }
        .related-to {
            background: #e8f4f8;
            padding: 10px 15px;
            border-radius: 4px;
            margin-top: 8px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <!-- Club Logo -->
            <?php if($clubSettings && $clubSettings->logo_path): ?>
            <div class="logo">
                <img src="<?php echo e(base_path('storage/app/public/' . $clubSettings->logo_path)); ?>" alt="Club Logo">
            </div>
            <?php endif; ?>

            <!-- Club Info -->
            <div class="club-info">
                <h1><?php echo e($clubSettings ? $clubSettings->name : config('club.name')); ?></h1>
                <p><?php echo e($clubSettings ? $clubSettings->address : (is_array(config('club.address')) ? implode(', ', array_filter(config('club.address'))) : config('club.address'))); ?></p>
                <p>Phone: <?php echo e($clubSettings ? $clubSettings->phone : config('club.phone')); ?></p>
                <p>Email: <?php echo e($clubSettings ? $clubSettings->email : config('club.email')); ?></p>
                <?php if($clubSettings && $clubSettings->registration_number): ?>
                    <p>Registration No: <?php echo e($clubSettings->registration_number); ?></p>
                <?php endif; ?>
                <?php if($clubSettings && $clubSettings->tax_number): ?>
                    <p>Tax No: <?php echo e($clubSettings->tax_number); ?></p>
                <?php endif; ?>
            </div>

            <div class="receipt-title">TRANSACTION RECEIPT</div>
            <div class="receipt-number">#<?php echo e($transaction->transaction_number); ?></div>
        </div>

        <div class="info-section">
            <div class="info-row">
                <span class="label">Date:</span>
                <span class="value"><?php echo e($transaction->transaction_date->format('F d, Y')); ?></span>
            </div>
            <div class="info-row">
                <span class="label">Type:</span>
                <span class="value"><?php echo e(ucfirst($transaction->type)); ?></span>
            </div>
            <div class="info-row">
                <span class="label">Category:</span>
                <span class="value"><?php echo e(ucfirst($transaction->category)); ?></span>
            </div>
            <div class="info-row">
                <span class="label">Payment Method:</span>
                <span class="value"><?php echo e(ucfirst(str_replace('_', ' ', $transaction->payment_method))); ?></span>
            </div>
            <div class="info-row">
                <span class="label">Bank Account:</span>
                <span class="value"><?php echo e($transaction->bankAccount->bank_name); ?> - <?php echo e($transaction->bankAccount->account_number); ?></span>
            </div>
            <?php if($transaction->reference_number): ?>
            <div class="info-row">
                <span class="label">Reference Number:</span>
                <span class="value"><?php echo e($transaction->reference_number); ?></span>
            </div>
            <?php endif; ?>
        </div>

        <div class="info-section">
            <div class="info-row">
                <span class="label">Description:</span>
                <span class="value"><?php echo e($transaction->description); ?></span>
            </div>
            <div class="info-row">
                <span class="label">Amount:</span>
                <span class="value amount">LKR <?php echo e(number_format($transaction->amount, 2)); ?></span>
            </div>
            <div class="info-row">
                <span class="label">Status:</span>
                <span class="value">
                    <span class="status status-<?php echo e($transaction->status); ?>"><?php echo e(ucfirst($transaction->status)); ?></span>
                </span>
            </div>
        </div>

        <?php if($transaction->transactionable && $transaction->transactionable_type !== 'other'): ?>
        <div class="related-to">
            <div class="info-row">
                <span class="label">Related To:</span>
                <span class="value">
                    <?php echo e(class_basename($transaction->transactionable_type)); ?> - 
                    <?php echo e($transaction->transactionable->name ?? $transaction->transactionable->company_name ?? 'N/A'); ?>

                </span>
            </div>
        </div>
        <?php endif; ?>

        <?php if($transaction->signature): ?>
        <div class="signature-section">
            <img src="<?php echo e(base_path('storage/app/public/' . $transaction->signature)); ?>" alt="Signature" class="signature-image">
            <div class="signature-info">
                <div>Authorized Signature</div>
                <?php if($transaction->signatory_name): ?>
                    <div style="font-weight: 500; margin-top: 3px;"><?php echo e($transaction->signatory_name); ?></div>
                <?php endif; ?>
                <?php if($transaction->signatory_designation): ?>
                    <div style="color: #666;"><?php echo e($transaction->signatory_designation); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="footer">
            <p>This is a computer generated receipt.</p>
            <p>Generated on: <?php echo e(now()->format('F d, Y h:i A')); ?></p>
            <p style="color: #2c3e50; font-weight: 500;"><?php echo e($clubSettings->name ?? config('app.name')); ?> - Building Champions of Tomorrow</p>
        </div>
    </div>
</body>
</html> <?php /**PATH C:\Users\Dhanushka\Desktop\yssc-system\resources\views/financial-transactions/receipt.blade.php ENDPATH**/ ?>