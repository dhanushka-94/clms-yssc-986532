<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Financial Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .header h1 {
            color: #1a1a1a;
            margin-bottom: 5px;
        }
        .header p {
            color: #666;
            margin: 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        .filters {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
        }
        .filters p {
            margin: 5px 0;
        }
        .income {
            color: #16a34a;
        }
        .expense {
            color: #dc2626;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            color: #666;
            font-size: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Financial Transaction Report</h1>
        <p>Generated on: <?php echo e($generatedAt->format('Y-m-d H:i:s')); ?></p>
    </div>

    <?php if(!empty($filters)): ?>
    <div class="filters">
        <h3>Applied Filters:</h3>
        <?php if(!empty($filters['date_from'])): ?>
            <p>Date From: <?php echo e($filters['date_from']); ?></p>
        <?php endif; ?>
        <?php if(!empty($filters['date_to'])): ?>
            <p>Date To: <?php echo e($filters['date_to']); ?></p>
        <?php endif; ?>
        <?php if(!empty($filters['type'])): ?>
            <p>Type: <?php echo e(ucfirst($filters['type'])); ?></p>
        <?php endif; ?>
        <?php if(!empty($filters['category'])): ?>
            <p>Category: <?php echo e(ucfirst(str_replace('_', ' ', $filters['category']))); ?></p>
        <?php endif; ?>
        <?php if(!empty($filters['payment_method'])): ?>
            <p>Payment Method: <?php echo e(ucfirst(str_replace('_', ' ', $filters['payment_method']))); ?></p>
        <?php endif; ?>
        <?php if(!empty($filters['status'])): ?>
            <p>Status: <?php echo e(ucfirst($filters['status'])); ?></p>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>Transaction Number</th>
                <th>Date</th>
                <th>Type</th>
                <th>Category</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Payment Method</th>
                <th>Bank Account</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($transaction->transaction_number); ?></td>
                    <td><?php echo e($transaction->transaction_date->format('Y-m-d')); ?></td>
                    <td><?php echo e(ucfirst($transaction->type)); ?></td>
                    <td><?php echo e(ucfirst(str_replace('_', ' ', $transaction->category))); ?></td>
                    <td class="<?php echo e($transaction->type); ?>">
                        LKR <?php echo e(number_format($transaction->amount, 2)); ?>

                    </td>
                    <td><?php echo e(ucfirst($transaction->status)); ?></td>
                    <td><?php echo e(ucfirst(str_replace('_', ' ', $transaction->payment_method))); ?></td>
                    <td><?php echo e($transaction->bankAccount->bank_name); ?> - <?php echo e($transaction->bankAccount->account_number); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" style="text-align: center;">No transactions found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="footer">
        <p>This is a computer-generated document. No signature is required.</p>
    </div>
</body>
</html> <?php /**PATH C:\Users\Dhanushka\Desktop\yssc-system\resources\views\reports\exports\pdf.blade.php ENDPATH**/ ?>