<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['event', 'players', 'staff', 'members', 'selectedPlayers', 'selectedStaff', 'selectedMembers']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['event', 'players', 'staff', 'members', 'selectedPlayers', 'selectedStaff', 'selectedMembers']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $title = $event->title;
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Event')); ?>: <?php echo e($title); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="flex justify-between items-center mb-6">
                        <h2 class="text-2xl font-semibold text-gray-900"><?php echo e(__('Edit Event')); ?></h2>
                        <a href="<?php echo e(route('events.show', $event)); ?>" class="text-yellow-600 hover:text-yellow-900"><?php echo e(__('Back to Event')); ?></a>
                    </div>

                    <form method="POST" action="<?php echo e(route('events.update', $event)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <?php if (isset($component)) { $__componentOriginala0923805759d399feafbf8497f9e5245 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0923805759d399feafbf8497f9e5245 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.events.form','data' => ['event' => $event,'players' => $players,'staff' => $staff,'members' => $members,'selectedPlayers' => $selectedPlayers,'selectedStaff' => $selectedStaff,'selectedMembers' => $selectedMembers]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('events.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['event' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event),'players' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($players),'staff' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($staff),'members' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($members),'selectedPlayers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($selectedPlayers),'selectedStaff' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($selectedStaff),'selectedMembers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($selectedMembers)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0923805759d399feafbf8497f9e5245)): ?>
<?php $attributes = $__attributesOriginala0923805759d399feafbf8497f9e5245; ?>
<?php unset($__attributesOriginala0923805759d399feafbf8497f9e5245); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0923805759d399feafbf8497f9e5245)): ?>
<?php $component = $__componentOriginala0923805759d399feafbf8497f9e5245; ?>
<?php unset($__componentOriginala0923805759d399feafbf8497f9e5245); ?>
<?php endif; ?>

                        <div class="mt-6 flex items-center justify-end gap-x-6">
                            <a href="<?php echo e(route('events.show', $event)); ?>" class="text-sm font-semibold leading-6 text-gray-900"><?php echo e(__('Cancel')); ?></a>
                            <button type="submit" class="rounded-md bg-yellow-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-yellow-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-yellow-600"><?php echo e(__('Update Event')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> <?php /**PATH C:\Users\Dhanushka\Desktop\yssc-system\resources\views/events/edit.blade.php ENDPATH**/ ?>