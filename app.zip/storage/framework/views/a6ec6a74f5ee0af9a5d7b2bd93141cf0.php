<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['event', 'attendees', 'existingAttendances', 'type']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['event', 'attendees', 'existingAttendances', 'type']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="space-y-6">
    <!-- Attendee Type Selector -->
    <div class="p-4 bg-gray-50 rounded-lg">
        <h4 class="text-sm font-medium text-gray-900">Select Attendee Type</h4>
        <div class="flex items-center gap-4 mt-2">
            <a href="<?php echo e(request()->fullUrlWithQuery(['type' => 'players'])); ?>" 
               class="px-3 py-2 text-sm font-medium rounded-md <?php echo e($type === 'players' ? 'bg-indigo-100 text-indigo-700' : 'bg-white text-gray-700'); ?>">
                Players
            </a>
            <a href="<?php echo e(request()->fullUrlWithQuery(['type' => 'staff'])); ?>" 
               class="px-3 py-2 text-sm font-medium rounded-md <?php echo e($type === 'staff' ? 'bg-indigo-100 text-indigo-700' : 'bg-white text-gray-700'); ?>">
                Staff
            </a>
            <a href="<?php echo e(request()->fullUrlWithQuery(['type' => 'members'])); ?>" 
               class="px-3 py-2 text-sm font-medium rounded-md <?php echo e($type === 'members' ? 'bg-indigo-100 text-indigo-700' : 'bg-white text-gray-700'); ?>">
                Members
            </a>
        </div>
    </div>

    <!-- Bulk Actions -->
    <div class="p-4 bg-gray-50 rounded-lg">
        <h4 class="text-sm font-medium text-gray-900">Bulk Actions</h4>
        <div class="flex items-center gap-4 mt-2">
            <select id="bulkStatus" class="block w-48 rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                <option value="">Select Status</option>
                <option value="present">Present</option>
                <option value="absent">Absent</option>
                <option value="late">Late</option>
                <option value="excused">Excused</option>
            </select>
            <button type="button" onclick="applyBulkStatus()" class="px-3 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-md shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
                Apply to All
            </button>
        </div>
    </div>

    <input type="hidden" name="type" value="<?php echo e($type); ?>">

    <!-- Attendance Table -->
    <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
        <table class="min-w-full divide-y divide-gray-300">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6">Name</th>
                    <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Status</th>
                    <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Check In</th>
                    <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Check Out</th>
                    <th scope="col" class="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Remarks</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200 bg-white">
                <?php $__empty_1 = true; $__currentLoopData = $attendees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $attendance = $existingAttendances->firstWhere('attendee_id', $attendee->id);
                    ?>
                    <tr>
                        <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                            <input type="hidden" name="attendances[<?php echo e($loop->index); ?>][attendee_id]" value="<?php echo e($attendee->id); ?>">
                            <?php echo e($attendee->first_name); ?> <?php echo e($attendee->last_name); ?>

                            <?php if(isset($attendee->jersey_number)): ?>
                                <span class="ml-1 text-gray-500">#<?php echo e($attendee->jersey_number); ?></span>
                            <?php endif; ?>
                            <?php if(isset($attendee->role)): ?>
                                <span class="ml-1 text-gray-500">(<?php echo e($attendee->role); ?>)</span>
                            <?php endif; ?>
                            <?php if(isset($attendee->membership_type)): ?>
                                <span class="ml-1 text-gray-500">(<?php echo e($attendee->membership_type); ?>)</span>
                            <?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            <select name="attendances[<?php echo e($loop->index); ?>][status]" class="attendance-status block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                                <option value="present" <?php if($attendance?->status === 'present'): echo 'selected'; endif; ?>>Present</option>
                                <option value="absent" <?php if(!$attendance || $attendance->status === 'absent'): echo 'selected'; endif; ?>>Absent</option>
                                <option value="late" <?php if($attendance?->status === 'late'): echo 'selected'; endif; ?>>Late</option>
                                <option value="excused" <?php if($attendance?->status === 'excused'): echo 'selected'; endif; ?>>Excused</option>
                            </select>
                        </td>
                        <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            <input type="time" name="attendances[<?php echo e($loop->index); ?>][check_in_time]" value="<?php echo e($attendance?->check_in_time?->format('H:i')); ?>" class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                        </td>
                        <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            <input type="time" name="attendances[<?php echo e($loop->index); ?>][check_out_time]" value="<?php echo e($attendance?->check_out_time?->format('H:i')); ?>" class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                        </td>
                        <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            <input type="text" name="attendances[<?php echo e($loop->index); ?>][remarks]" value="<?php echo e($attendance?->remarks); ?>" placeholder="Add remarks..." class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-3 py-4 text-sm text-center text-gray-500">
                            No <?php echo e(str($type)->singular()); ?> found
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function applyBulkStatus() {
    const status = document.getElementById('bulkStatus').value;
    if (!status) return;

    const statusSelects = document.querySelectorAll('.attendance-status');
    statusSelects.forEach(select => {
        select.value = status;
    });
}
</script> <?php /**PATH C:\Users\Dhanushka\Desktop\yssc-system\resources\views/components/attendances/form.blade.php ENDPATH**/ ?>