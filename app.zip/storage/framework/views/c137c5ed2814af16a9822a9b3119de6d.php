<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Invoice #<?php echo e($transaction->transaction_number); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        @page {
            margin: 0;
            size: A4;
            padding: 0;
        }
        body {
            font-family: 'Helvetica', Arial, sans-serif;
            color: #2d3748;
            line-height: 1.4;
            font-size: 10px;
            margin: 0;
            padding: 20px;
            background: white;
        }
        .header {
            position: relative;
            background: #f8fafc;
            margin: -20px -20px 25px -20px;
            padding: 25px;
            color: #2d3748;
            border-bottom: 1px solid #e2e8f0;
        }
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
        }
        .brand-section {
            flex: 2;
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .logo {
            background: white;
            padding: 12px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            min-width: 100px;
        }
        .logo img {
            width: 80px;
            height: 80px;
            object-fit: contain;
        }
        .company-info {
            color: #2d3748;
            flex: 1;
        }
        .company-info h1 {
            color: #1a202c;
            font-size: 24px;
            margin: 0 0 10px 0;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            line-height: 1.2;
        }
        .company-info p {
            color: #4a5568;
            margin: 4px 0;
            font-size: 12px;
        }
        .invoice-details {
            flex: 1;
            background: white;
            padding: 20px;
            border-radius: 8px;
            color: #2d3748;
            border: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            min-width: 250px;
        }
        .invoice-title {
            font-size: 24px;
            color: #2d3748;
            margin: 0 0 12px 0;
            font-weight: 800;
            letter-spacing: 1px;
            text-transform: uppercase;
            text-align: right;
        }
        .invoice-number {
            font-size: 14px;
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e2e8f0;
            text-align: right;
        }
        .invoice-meta {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            font-size: 10px;
        }
        .meta-item {
            margin-bottom: 8px;
        }
        .meta-label {
            font-weight: 600;
            color: #4a5568;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 2px;
        }
        .meta-value {
            color: #2d3748;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .status-completed { background: #e8f5e9; color: #1b5e20; }
        .status-pending { background: #fff3e0; color: #e65100; }
        .status-cancelled { background: #ffebee; color: #b71c1c; }
        .main-content {
            margin: 20px 0;
            display: flex;
            gap: 25px;
        }
        .left-section, .right-section {
            flex: 1;
        }
        .section-title {
            font-size: 12px;
            color: #1a1a1a;
            margin-bottom: 8px;
            font-weight: 600;
        }
        .info-grid {
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 6px;
            margin-bottom: 15px;
        }
        .label {
            color: #4a4a4a;
            font-weight: 500;
        }
        .value {
            color: #1a1a1a;
        }
        .transaction-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .transaction-table th {
            background: #f5f5f5;
            padding: 8px;
            text-align: left;
            font-weight: 600;
            color: #1a1a1a;
            border-bottom: 2px solid #e0e0e0;
            font-size: 10px;
        }
        .transaction-table td {
            padding: 8px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 10px;
            color: #1a1a1a;
        }
        .amount-col {
            text-align: right;
            font-family: 'Courier New', monospace;
        }
        .total-row td {
            font-weight: 600;
            color: #1a1a1a;
            border-top: 2px solid #e0e0e0;
            border-bottom: none;
        }
        .signature-section {
            margin-top: 25px;
            display: flex;
            justify-content: flex-end;
        }
        .signature-box {
            text-align: center;
            width: 160px;
        }
        .signature-image {
            max-width: 120px;
            height: 50px;
            margin: 0 auto 8px;
            object-fit: contain;
        }
        .signature-line {
            width: 100%;
            height: 1px;
            background: #e0e0e0;
            margin-bottom: 4px;
        }
        .signature-info {
            font-size: 9px;
            color: #4a4a4a;
        }
        .footer {
            margin-top: 25px;
            text-align: center;
            color: #4a4a4a;
            font-size: 9px;
            border-top: 1px solid #e0e0e0;
            padding-top: 15px;
        }
        .attachments {
            margin-top: 15px;
            font-size: 9px;
            color: #4a4a4a;
        }
        .attachments ul {
            list-style: none;
            padding: 0;
            margin: 3px 0;
        }
        .attachments li {
            margin: 2px 0;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <div class="brand-section">
                <?php if($clubSettings && $clubSettings->logo_path): ?>
                <div class="logo">
                    <img src="<?php echo e(public_path('images/' . $clubSettings->logo_path)); ?>" alt="Club Logo">
                </div>
                <?php endif; ?>
                
                <div class="company-info">
                    <h1><?php echo e($clubSettings ? $clubSettings->name : config('club.name')); ?></h1>
                    <p><?php echo e($clubSettings ? $clubSettings->address : config('club.address')); ?></p>
                    <p>Phone: <?php echo e($clubSettings ? $clubSettings->phone : config('club.phone')); ?></p>
                    <p>Email: <?php echo e($clubSettings ? $clubSettings->email : config('club.email')); ?></p>
                    <?php if($clubSettings && $clubSettings->registration_number): ?>
                        <p>Registration No: <?php echo e($clubSettings->registration_number); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="invoice-details">
                <div class="invoice-title">INVOICE</div>
                <div class="invoice-number">#<?php echo e($transaction->transaction_number); ?></div>
                <div class="invoice-meta">
                    <div class="meta-item">
                        <div class="meta-label">Issue Date</div>
                        <div class="meta-value"><?php echo e($transaction->transaction_date->format('F d, Y')); ?></div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Due Date</div>
                        <div class="meta-value"><?php echo e($transaction->transaction_date->addDays(30)->format('F d, Y')); ?></div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Status</div>
                        <div class="meta-value">
                            <span class="status-badge status-<?php echo e($transaction->status); ?>"><?php echo e(ucfirst($transaction->status)); ?></span>
                        </div>
                    </div>
                    <div class="meta-item">
                        <div class="meta-label">Payment Terms</div>
                        <div class="meta-value">Net 30</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div class="left-section">
            <div class="section-title">Bill To</div>
            <div class="info-grid">
                <?php if($transaction->transactionable): ?>
                    <span class="label">Name:</span>
                    <span class="value">
                        <?php if($transaction->transactionable instanceof \App\Models\Sponsor): ?>
                            <?php echo e($transaction->transactionable->name); ?>

                        <?php elseif($transaction->transactionable instanceof \App\Models\Player || $transaction->transactionable instanceof \App\Models\Staff || $transaction->transactionable instanceof \App\Models\Member): ?>
                            <?php echo e($transaction->transactionable->first_name); ?> <?php echo e($transaction->transactionable->last_name); ?>

                        <?php else: ?>
                            <?php echo e($transaction->transactionable->name ?? 'N/A'); ?>

                        <?php endif; ?>
                    </span>
                    <span class="label">Type:</span>
                    <span class="value"><?php echo e(class_basename($transaction->transactionable_type)); ?></span>
                    <?php if(isset($transaction->transactionable->email)): ?>
                        <span class="label">Email:</span>
                        <span class="value"><?php echo e($transaction->transactionable->email); ?></span>
                    <?php endif; ?>
                    <?php if(isset($transaction->transactionable->phone)): ?>
                        <span class="label">Phone:</span>
                        <span class="value"><?php echo e($transaction->transactionable->phone); ?></span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="label">Name:</span>
                    <span class="value">General Transaction</span>
                <?php endif; ?>
            </div>
        </div>
        <div class="right-section">
            <div class="section-title">Payment Details</div>
            <div class="info-grid">
                <span class="label">Method:</span>
                <span class="value"><?php echo e(ucfirst(str_replace('_', ' ', $transaction->payment_method))); ?></span>
                <span class="label">Bank:</span>
                <span class="value"><?php echo e($transaction->bankAccount->bank_name); ?></span>
                <span class="label">Account:</span>
                <span class="value"><?php echo e($transaction->bankAccount->account_number); ?></span>
                <?php if($transaction->reference_number): ?>
                    <span class="label">Reference:</span>
                    <span class="value"><?php echo e($transaction->reference_number); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <table class="transaction-table">
        <thead>
            <tr>
                <th style="width: 45%;">Description</th>
                <th style="width: 25%;">Category</th>
                <th style="width: 30%;" class="amount-col">Amount (LKR)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($transaction->description ?: 'N/A'); ?></td>
                <td><?php echo e(ucfirst($transaction->category)); ?></td>
                <td class="amount-col"><?php echo e(number_format($transaction->amount, 2)); ?></td>
            </tr>
            <tr class="total-row">
                <td colspan="2" style="text-align: right;">Total Amount:</td>
                <td class="amount-col"><?php echo e(number_format($transaction->amount, 2)); ?></td>
            </tr>
        </tbody>
    </table>

    <?php if($transaction->attachments && count($transaction->attachments) > 0): ?>
    <div class="attachments">
        <div class="section-title">Attachments</div>
        <ul>
            <?php $__currentLoopData = $transaction->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>• <?php echo e(basename($attachment)); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <?php if($transaction->signature || ($clubSettings && $clubSettings->default_signature)): ?>
    <div class="signature-section">
        <div class="signature-box">
            <?php
                $signaturePath = null;
                if ($transaction->signature && Storage::disk('public')->exists($transaction->signature)) {
                    $signaturePath = storage_path('app/public/' . $transaction->signature);
                } elseif ($clubSettings && $clubSettings->default_signature && Storage::disk('public')->exists($clubSettings->default_signature)) {
                    $signaturePath = storage_path('app/public/' . $clubSettings->default_signature);
                }
            ?>
            
            <?php if($signaturePath): ?>
                <img src="<?php echo e($signaturePath); ?>" alt="Signature" class="signature-image">
            <?php endif; ?>
            <div class="signature-line"></div>
            <div class="signature-info">
                <div>Authorized Signature</div>
                <?php if($transaction->signatory_name): ?>
                    <div style="font-weight: 600; margin: 3px 0;"><?php echo e($transaction->signatory_name); ?></div>
                <?php elseif($clubSettings && $clubSettings->default_signatory_name): ?>
                    <div style="font-weight: 600; margin: 3px 0;"><?php echo e($clubSettings->default_signatory_name); ?></div>
                <?php endif; ?>
                <?php if($transaction->signatory_designation): ?>
                    <div><?php echo e($transaction->signatory_designation); ?></div>
                <?php elseif($clubSettings && $clubSettings->default_signatory_designation): ?>
                    <div><?php echo e($clubSettings->default_signatory_designation); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="footer">
        <p><?php echo e($clubSettings->name ?? config('app.name')); ?> - Building Champions of Tomorrow</p>
    </div>
</body>
</html> <?php /**PATH C:\Users\Dhanushka\Desktop\yssc-system\resources\views/financial-transactions/invoice.blade.php ENDPATH**/ ?>