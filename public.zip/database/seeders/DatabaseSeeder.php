<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Role;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Create roles
        $roles = [
            [
                'name' => 'admin',
                'display_name' => 'Administrator',
                'description' => 'System Administrator'
            ],
            [
                'name' => 'staff',
                'display_name' => 'Staff',
                'description' => 'Staff Member'
            ],
            [
                'name' => 'member',
                'display_name' => 'Member',
                'description' => 'Club Member'
            ],
            [
                'name' => 'player',
                'display_name' => 'Player',
                'description' => 'Club Player'
            ]
        ];

        foreach ($roles as $role) {
            Role::create($role);
        }

        // Create system users
        $users = [
            [
                'name' => 'System Admin',
                'email' => 'admin@yssc.com',
                'password' => Hash::make('password'),
                'email_verified_at' => now(),
                'role' => 'admin'
            ],
            [
                'name' => 'Staff User',
                'email' => 'staff@yssc.com',
                'password' => Hash::make('password'),
                'email_verified_at' => now(),
                'role' => 'staff'
            ]
        ];

        foreach ($users as $userData) {
            $role = $userData['role'];
            unset($userData['role']);
            
            $user = User::create($userData);
            $roleModel = Role::where('name', $role)->first();
            $user->roles()->attach($roleModel->id);
        }
    }
}
