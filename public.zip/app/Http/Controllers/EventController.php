<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Player;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class EventController extends Controller
{
    public function index(): View
    {
        $events = Event::with(['players'])
            ->latest('start_time')
            ->paginate(10);

        $upcomingEvents = Event::where('start_time', '>', now())
            ->where('status', 'scheduled')
            ->count();

        $completedEvents = Event::where('status', 'completed')->count();

        return view('events.index', compact('events', 'upcomingEvents', 'completedEvents'));
    }

    public function create(): View
    {
        $players = Player::where('status', 'active')->get();
        return view('events.create', compact('players'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'type' => ['required', 'in:match,practice,meeting'],
            'start_time' => ['required', 'date'],
            'end_time' => ['required', 'date', 'after:start_time'],
            'location' => ['nullable', 'string'],
            'opponent' => ['nullable', 'required_if:type,match', 'string'],
            'venue' => ['nullable', 'required_if:type,match', 'in:home,away,neutral'],
            'meeting_link' => ['nullable', 'url'],
            'status' => ['required', 'in:scheduled,in_progress,completed,cancelled'],
            'attachments.*' => ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf,doc,docx', 'max:2048'],
            'players' => ['array'],
            'players.*' => ['exists:players,id']
        ]);

        try {
            DB::beginTransaction();

            $event = Event::create($request->except('attachments', 'players'));

            if ($request->hasFile('attachments')) {
                $event->storeAttachments($request->file('attachments'));
            }

            // Create attendance records for selected players
            if ($request->has('players')) {
                foreach ($request->players as $playerId) {
                    $event->attendances()->create([
                        'player_id' => $playerId,
                        'status' => 'absent' // Default status
                    ]);
                }
            }

            DB::commit();

            return redirect()->route('events.show', $event)
                ->with('success', 'Event created successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Failed to create event. ' . $e->getMessage());
        }
    }

    public function show(Event $event): View
    {
        $event->load(['players', 'attendances.player']);
        
        $attendanceStats = [
            'present' => $event->presentPlayers()->count(),
            'absent' => $event->absentPlayers()->count(),
            'late' => $event->latePlayers()->count(),
            'excused' => $event->excusedPlayers()->count(),
        ];

        return view('events.show', compact('event', 'attendanceStats'));
    }

    public function edit(Event $event): View
    {
        $players = Player::where('status', 'active')->get();
        $selectedPlayers = $event->players->pluck('id')->toArray();
        
        return view('events.edit', compact('event', 'players', 'selectedPlayers'));
    }

    public function update(Request $request, Event $event)
    {
        $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'type' => ['required', 'in:match,practice,meeting'],
            'start_time' => ['required', 'date'],
            'end_time' => ['required', 'date', 'after:start_time'],
            'location' => ['nullable', 'string'],
            'opponent' => ['nullable', 'required_if:type,match', 'string'],
            'venue' => ['nullable', 'required_if:type,match', 'in:home,away,neutral'],
            'meeting_link' => ['nullable', 'url'],
            'status' => ['required', 'in:scheduled,in_progress,completed,cancelled'],
            'attachments.*' => ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf,doc,docx', 'max:2048'],
            'players' => ['array'],
            'players.*' => ['exists:players,id']
        ]);

        try {
            DB::beginTransaction();

            $event->update($request->except('attachments', 'players'));

            if ($request->hasFile('attachments')) {
                $event->storeAttachments($request->file('attachments'));
            }

            // Update player attendance records
            if ($request->has('players')) {
                $currentPlayers = $event->players->pluck('id')->toArray();
                $newPlayers = $request->players;

                // Remove players not in the new list
                $playersToRemove = array_diff($currentPlayers, $newPlayers);
                if (!empty($playersToRemove)) {
                    $event->attendances()->whereIn('player_id', $playersToRemove)->delete();
                }

                // Add new players
                $playersToAdd = array_diff($newPlayers, $currentPlayers);
                foreach ($playersToAdd as $playerId) {
                    $event->attendances()->create([
                        'player_id' => $playerId,
                        'status' => 'absent' // Default status
                    ]);
                }
            }

            DB::commit();

            return redirect()->route('events.show', $event)
                ->with('success', 'Event updated successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Failed to update event. ' . $e->getMessage());
        }
    }

    public function destroy(Event $event)
    {
        try {
            $event->delete();
            return redirect()->route('events.index')
                ->with('success', 'Event deleted successfully.');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to delete event. ' . $e->getMessage());
        }
    }
}
